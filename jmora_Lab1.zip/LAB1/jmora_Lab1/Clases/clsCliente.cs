﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace jmora_Lab1.Clases
{
    internal class clsCliente
    {
        #region Atributos
        private int id;
        private string primerNombre, segundoNombre, primerApellido, segundoApellido, sexo, alergias;
        private double peso;
        private DateTime fechaNacimiento;
        #endregion


        #region Constructores
        public clsCliente()
        {
            this.id= 0;
            this.primerNombre = "";
            this.segundoNombre = "";
            this.primerApellido = "";
            this.segundoApellido = "";
            this.fechaNacimiento = Convert.ToDateTime("2/6/2023");
            this.peso = 0.0;
            this.sexo = "";
            this.alergias = "";
        }

        public clsCliente(int iden, string pnom, string snom, string pape, string sape, DateTime fechaNacimiento, string sexo, string alergias, double peso)
        {
            this.id = iden;
            this.primerNombre = pnom;
            this.segundoNombre = snom;
            this.primerApellido = pape;
            this.segundoApellido = sape;
            this.fechaNacimiento = fechaNacimiento;
            this.sexo = sexo;
            this.alergias = alergias;
            this.peso = peso;
        }

        #endregion

        #region Funciones y Procedimientos
        public string imprimirDatos()
        {
            string dato = "";
            dato = "Nombre Completo" + this.primerNombre + " " + this.segundoNombre + "\n" +
            this.primerApellido + " " + this.segundoApellido + "\n" + "Fecha de nacimiento " + this.fechaNacimiento + "\n" +
            "Peso y Sexo " + this.peso + " " + this.sexo + "\n" + "Alergias " + this.alergias;
            return dato;

        }
        #endregion

        #region Metodos
        public int Id
        {
            set { id = value; }
            get { return id; }
        }

        public string PrimerNombre
        {
            set { primerNombre = value; }
            get { return primerNombre; }
        }

        public string SegundoNombre
        {
            set { segundoNombre = value; }
            get { return segundoNombre; }
        }

        public string PrimerApellido
        {
            set { primerApellido = value; }
            get { return primerApellido; }
        }

        public string SegundoApellido
        {
            set { segundoApellido = value; }
            get { return segundoApellido; }
        }

        public DateTime FechaNacimiento
        {
            set { fechaNacimiento = value; }
            get { return fechaNacimiento; }
        }

        public double Peso
        {
            set { peso = value; }
            get { return peso; }
        }

        public string Sexo
        {
            set { sexo = value; }
            get { return sexo; }
        }

        public string Alergias
        {
            set { alergias = value; }
            get { return alergias; }
        }
        #endregion
    }
}
