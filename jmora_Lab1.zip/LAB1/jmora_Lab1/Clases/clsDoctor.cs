﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace jmora_Lab1.Clases
{
    internal class clsDoctor
    {
        #region Atributos
        private int id;
        private string primerNombre, segundoNombre, primerApellido, segundoApellido, codigoColegio;
        #endregion

        #region Constructores
        public clsDoctor()
        {
            this.id = 0;
            this.primerNombre = "";
            this.segundoNombre = "";
            this.primerApellido = "";
            this.segundoApellido = "";
            this.codigoColegio = "";
        }

        public clsDoctor(int ide, string pnom, string snom, string pape, string sape, string codigoColegio)
        {
            this.id = ide;
            this.primerNombre = pnom;
            this.segundoNombre = snom;
            this.primerApellido = pape;
            this.segundoApellido = sape;
            this.codigoColegio = codigoColegio;
        }
        #endregion

        #region Funciones y Procedimientos
        public string imprimirDatos()
        {
            string dato = "";
            dato = "Nombre Completo" + this.primerNombre + " " + this.segundoNombre + "\n" +
            this.primerApellido + " " + this.segundoApellido + "\n" + "Código de Colegio Medico " + this.codigoColegio;    
            return dato;
            #endregion
            
        }
        #region Metodos
        public int Id
        {
            set { id = value; }
            get { return id; }
        }

        public string PrimerNombre
        {
            set { primerNombre = value; }
            get { return primerNombre; }
        }

        public string SegundoNombre
        {
            set { segundoNombre = value; }
            get { return segundoNombre; }
        }

        public string PrimerApellido
        {
            set { primerApellido = value; }
            get { return primerApellido; }
        }

        public string SegundoApellido
        {
            set { segundoApellido = value; }
            get { return segundoApellido; }
        }

        public string CodigoColegio
        {
            set { codigoColegio = value; }
            get { return codigoColegio; }
        }
        #endregion
    }
}
