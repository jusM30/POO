﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace jmora_Lab1.Clases
{
    internal class clsReceta
    {
        #region Atributos
        private int id, idDoctor;
        private string descripcion, tratamiento, dosisIndicadas;
        #endregion


        #region Constructores
        public clsReceta()
        {
            this.id = 0;
            this.idDoctor = 0;
            this.descripcion = "";
            this.tratamiento = "";
            this.dosisIndicadas = "";
        }
        public clsReceta(int iden, int idDoctor, string descripcion, string tratamiento, string dosisIndicadas)
        {
            this.id = iden;
            this.idDoctor = idDoctor;
            this.descripcion = descripcion;
            this.tratamiento = tratamiento;
            this.dosisIndicadas = dosisIndicadas;
        }
        #endregion

        #region Funciones y Procedimientos
        public string imprimirDatos()
        {
            string datos;
            datos = "Doctor " + this.idDoctor + "\n" + "Descripcion " + this.descripcion + "\n" + "Tratamiento " + this.tratamiento + ", Dosis indicadas " + this.dosisIndicadas;
            return datos;
        }
        #endregion

        #region Metodos
        public int Id
        {
            set { id = value; }
            get { return id; }
        }

        public int IdDoctor
        {
            set { idDoctor = value; }
            get { return idDoctor; }
        }

        public string Descripcion
        {
            set { descripcion = value; }
            get { return descripcion; }
        }

        public string Tratamiento
        {
            set { tratamiento = value; }
            get { return tratamiento; }
        }

        public string DosisIndicadas
        {
            set { dosisIndicadas = value; }
            get { return dosisIndicadas; }
        }
        #endregion
    }
}
