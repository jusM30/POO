﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace jmora_Lab1.Clases
{
    internal class clsFactura
    {
        #region Atributos
        private int id, telefono;
        private string razonSocial, cedulaJuridica, correoElectronico;
        private double totalPagar;
        #endregion

        #region Constructores
        public clsFactura()
        {
            this.id = 0;
            this.telefono = 0;
            this.razonSocial = "";
            this.cedulaJuridica = "";
            this.correoElectronico = "";
            this.totalPagar = 0;
        }
        public clsFactura(int iden, int telefono, string razonSocial, string cedulaJuridica, string correoElectronico, double totalPagar)
        {
            this.id = iden;
            this.telefono = telefono;
            this.razonSocial = razonSocial;
            this.cedulaJuridica = cedulaJuridica;
            this.correoElectronico = correoElectronico;
            this.totalPagar = totalPagar;
        }
        #endregion

        #region Funciones y Procedimientos
        public string imprimirDatos()
        {
            string datos;
            datos = "Razón Social " + this.razonSocial + "\n" + "Cédula Jurídica " + this.cedulaJuridica + "\n" + "Teléfono " + this.telefono + "\n"
                + "Correo Electrónico " + this.correoElectronico + "\n" + "Total a Pagar" + this.totalPagar;
            return datos;
            
        }
        #endregion

        #region Constructores
        public int Id
        {
            set { id = value; }
            get { return id; }
        }

        public string RazonSocial
        {
            set { razonSocial = value; }
            get { return razonSocial; }
        }

        public string CedulaJuridica
        {
            set { cedulaJuridica = value; }
            get { return cedulaJuridica; }
        }

        public int Telefono
        {
            set { Telefono = value; }
            get { return Telefono; }
        }

        public string CorreoElectronico
        {
            set { correoElectronico = value; }
            get { return correoElectronico; }
        }

        public double TotalPagar
        {
            set { totalPagar = value; }
            get { return totalPagar; }
        }

        #endregion
    }
}
