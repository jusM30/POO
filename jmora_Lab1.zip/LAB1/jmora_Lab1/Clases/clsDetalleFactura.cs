﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace jmora_Lab1.Clases
{
    internal class clsDetalleFactura
    {
        #region Atributos
        private int id, idFactura, cantidad;
        private string articulos;
        private double precio, porcentajeIVA, subtotal;
        #endregion

        #region constructores
        public clsDetalleFactura()
        {
            this.id= 0;
            this.idFactura= 0;
            this.articulos = "";
            this.cantidad = 0;
            this.precio= 0;
            this.porcentajeIVA= 0;
            this.subtotal= 0;
        }

        public clsDetalleFactura(int iden, int idedFactura, int cantidad, string articulos, double precio, double porcentajeIVA, double subtotal)
        {
            this.id = iden;
            this.idFactura = idedFactura;
            this.cantidad = cantidad;
            this.articulos = articulos;
            this.precio = precio;
            this.porcentajeIVA = porcentajeIVA;
            this.subtotal = subtotal;
        }
        #endregion

        #region Funciones y Procedimientos
        public string imprimirDatos()
        {
            string datos;
            datos = "Id de factura " + this.idFactura + "\n" + "Articulos " + this.articulos + ", " + "Cantidad " + this.cantidad + "\n" +
            "Precio " + this.precio + "\n" + "Porcentaje de IVA " + this.porcentajeIVA + "%" + "\n" + "Subtotal " + this.subtotal;
            return datos;
        }

        #endregion

        #region Metodos
        public int Id
        {
            set { id = value; }
            get { return id; }
        }

        public int IdFactura
        {
            set { idFactura = value; }
            get { return idFactura; }
        }

        public string Articulos
        {
            set { articulos = value; }
            get { return articulos; }
        }

        public int Cantidad
        {
            set { cantidad = value; }
            get { return cantidad; }
        }

        public double Precio
        {
            set { precio = value; }
            get { return precio; }
        }

        public double PorcentajeIVA
        {
            set { porcentajeIVA = value; }
            get { return porcentajeIVA; }
        }

        public double Subtotal
        {
            set { subtotal = value; }
            get { return subtotal; }
        }
        #endregion
    }
}
